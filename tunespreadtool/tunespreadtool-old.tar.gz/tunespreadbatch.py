# fixed parameters
twiss_file = '../twissfiles/SPS-inj25GeV.tfs'
scan = {                # comment out what you do not want to fix 
                        # (and instead read from file) :
        'n_part': (1.3e+11, 1.5e+11),
        'gamma': (27.7286, 27.7286 + 2),
        'sig_z': (0.22, 0.24),
        'deltaE': (0.0017, 0.003)#,
#        'emit_geom': (4.7e-08, 4.8e-08, 5e-08)
        }


from os import system as ex
from itertools import product

params = scan.keys()
combinations = [ dict( zip(params, joined) ) for joined in product(
                                        *(scan[p] for p in params) ) ]
labels = ' --labels '
for actualsetting in combinations:
    flags = ''
    for param, value in actualsetting.iteritems():
        flags += ' --' + param + ' ' + str(value)
    ex('python tunespread.py ' + twiss_file + labels + flags)
    labels = ''
